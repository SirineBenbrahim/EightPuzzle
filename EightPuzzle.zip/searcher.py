#
# searcher.py (Final Project)
#
# classes for objects that perform state-space search on Eight Puzzles
#
# name: Sirine Benbrahim
# email: sirineb@bu.edu
#
#

import random
from state import *

class Searcher:
    """ A class for objects that perform random state-space
        search on an Eight Puzzle.
        This will also be used as a superclass of classes for
        other state-space search algorithms.
    """
    ### Add your Searcher method definitions here. ###
    def __init__(self, init_state, depth_limit):
        """a constructor for a new Searcher object that initializes
           its attributes states, num_tested, and depth_limit"""
        self.states = [init_state]
        self.num_tested = 0
        self.depth_limit = depth_limit

    def should_add(self, state):
        """takes a State object called state and returns True if the
           called Searcher should add state to its list of untested states,
           and False otherwise"""
        if self.depth_limit != -1 and state.num_moves > self.depth_limit:  # False if the Searcher has a depth limit and state is beyoond the depth limit
            return False
        elif state.creates_cycle():   # False if the state is a cylce (is the same board - already appears in the sequence of moves that led to state)
            return False
        else:
            return True

    def add_state(self, new_state):
        """takes a single State object called new_state and adds it to the
           Searcher‘s list of untested states"""
        self.states += [new_state]

    def add_states(self, new_states):
        """takes a list State objects called new_states, and that processes
           the elements of new_states one at a time"""
        for s in new_states: 
            if self.should_add(s): # If should add s to Searcher's list of untested states, 
                self.add_state(s)  # Add s to list of states

    def next_state(self):
        """ chooses the next state to be tested from the list of 
            untested states, removing it from the list and returning it
        """
        s = random.choice(self.states) # Randomly choose one of the elements of the states list
        self.states.remove(s)          # Remove the selected state s from the states list
        return s

    def find_solution(self):
        """performs a full random state-space search, stopping when the goal
           state is found or when the Searcher runs out of untested states
        """
        while len(self.states) > 0: # Loop until the searcher runs out of untested states
            s = self.next_state()
            self.num_tested += 1    # Incrememnt Searcher object's num_tested
            if s.is_goal():
                return s
            else:
                s_successors = s.generate_successors()  # Generate successors for s if it's not the goal state
                self.add_states(s_successors)           # Add the successors to the list of states of self
        return None    # Failure (searcher runs out of untested states)

    def __repr__(self):
        """ returns a string representation of the Searcher object
            referred to by self.
        """
        # You should *NOT* change this method.
        s = str(len(self.states)) + ' untested, '
        s += str(self.num_tested) + ' tested, '
        if self.depth_limit == -1:
            s += 'no depth limit'
        else:
            s += 'depth limit = ' + str(self.depth_limit)
        return s


### Add your other class definitions below. ###
class BFSearcher(Searcher):
    """A class for objects that perform breadth-first
        search (always chooses one of the untested states
        that has the smallest depth (i.e., the smallest
        number of moves from the initial state) on an Eight
        Puzzle; a subclass of the Searcher class"""
    def next_state(self):
        """overrides (i.e., replaces) the next_state method that
           is inherited from Searcher; follows FIFO (first-in first-out)
           ordering – chooses the state that has been in the list the
           longest"""
        s = self.states[0]       # Choose the state that has been in the states list the longest (the first one)
        self.states.remove(s)    # Remove the selected state s from the states list
        return s

class DFSearcher(Searcher):
    """A class for objects that perform depth-first
       search (always chooses one of the untested states
       that has the largest depth (i.e., the largest number
       of moves from the initial state) on an Eight
       Puzzle; a sublclass of the Searcher class"""
    def next_state(self):
        """overrides (i.e., replaces) th next_state method that
           is inherited from Searcher; follows LIFO (last-in first-out)
           ordering – chooses the state that was most recently added to
           the list"""
        s = self.states[-1]     # Choose the state that was most recently added to the list (the last one)
        self.states.remove(s)   # Remove the selected state s from the states list
        return s

class GreedySearcher(Searcher):
    """A class for objects that perform greedy search (an informed search algorithm
       that uses a heuristic function to estimate the remaining cost needed to get
       from a given state to the goal state (how many additional moves are needed);
       uses this heuristic function to assign a priority to each state, and it selects
       the next state based on those priorities"""
    def priority(self, state):
        """takes a State object called state, and that computes and returns the priority
           of that state"""
        if self.heuristic == 1:                                       # Compute priority with distance heuristic
            heuristic = state.board.distances_from_correct_position()
        else:                                                         # Compute priority with misplaced tiles heuristic
            heuristic = state.board.num_misplaced()
        priority = -1 * heuristic
        return priority

    def __init__(self, init_state, heuristic, depth_limit):
        """ constructor for a GreedySearcher object
            inputs:
            * init_state - a State object for the initial state
            * heuristic - an integer specifying which heuristic
        function should be used when computing the priority
        of a state
            * depth_limit - the depth limit of the searcher
        """
        self.heuristic = heuristic
        self.states = [[self.priority(init_state), init_state]]
        self.num_tested = 0
        self.depth_limit = depth_limit

    def add_state(self, state):
        """overrides (i.e., replaces) the add_state method that is inherited from
           Searcher; adds a sublist that is a [priority, state] pair, where priority
           is the priority of state, as determined by calling the priority method
        """
        self.states += [[self.priority(state), state]]

    def next_state(self):
        """overrides (i.e., replaces) the next_state method that is inherited from
           Searcher; chooses one of the states with the highest priority"""
        best_state = max(self.states)      # Choose the state with the highest priority
        self.states.remove(best_state)     # Remove that state from the list of states
        return best_state[1]

class AStarSearcher(GreedySearcher):
    """A class for objects that perform A search (an informed search algorithm that
       assigns a priority to each state based on a heuristic function, and that selects
       the next state based on those priorities; when A* assigns a priority to a state,
       it also takes into account the cost that has already been expended to get to that
       state (i.e. the number of moves to that state))"""
    def priority(self, state):
        """takes a State object called state, and that computes and returns the priority
           of that state"""
        if self.heuristic == 1:                                        # Compute priority with distance heuristic
            heuristic = state.board.distances_from_correct_position()
        else:                                                          # Compute priority with misplaced tiles heuristic
            heuristic = state.board.num_misplaced()
        num_moves = state.num_moves
        priority = -1 * (heuristic + num_moves)
        return priority
