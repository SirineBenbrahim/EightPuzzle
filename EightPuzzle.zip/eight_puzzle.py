#
# eight_puzzle.py (Final Project)
#
# driver/test code for state-space search on Eight Puzzles
#
# name: Sirine Benbrahim
# email: sirineb@bu.edu
#
#

from searcher import *
from timer import *

def create_searcher(init_state, algorithm, extra):
    """ a function that creates and returns an appropriate
        searcher object, based on the specified inputs. 
        inputs:
          * init_state - a State object for the searcher's initial state
          * algorithm - a string specifying which algorithm the searcher
              should implement
          * extra - an optional extra parameter that can be used to
            specify either a depth limit or the number of a heuristic function
        Note: If an unknown value is passed in for the algorithm parameter,
        the function returns None.
    """
    searcher = None
    
    if algorithm == 'random':
        searcher = Searcher(init_state, extra)
## You will uncommment the following lines as you implement
## other algorithms.
    elif algorithm == 'BFS':
        searcher = BFSearcher(init_state, extra)
    elif algorithm == 'DFS':
        searcher = DFSearcher(init_state, extra)
    elif algorithm == 'Greedy':
        searcher = GreedySearcher(init_state, extra, -1)
    elif algorithm == 'A*':
        searcher = AStarSearcher(init_state, extra, -1)
    else:  
        print('unknown algorithm:', algorithm)

    return searcher

def eight_puzzle(init_boardstr, algorithm, extra=-1):
    """ a driver function for solving Eight Puzzles using state-space search
        inputs:
          * init_boardstr - a string of digits specifying the configuration
            of the board in the initial state
          * algorithm - a string specifying which algorithm you want to use
          * extra - an optional extra parameter that can be used to
            specify either a depth limit or the number of a heuristic function
    """
    init_board = Board(init_boardstr)
    init_state = State(init_board, None, 'init')

    searcher = create_searcher(init_state, algorithm, extra)
    if searcher == None:
        return

    soln = None
    timer = Timer(algorithm)
    timer.start()
    
    try:
        soln = searcher.find_solution()
    except KeyboardInterrupt:
        print('Search terminated.')

    timer.end()
    print(str(timer) + ', ', end='')
    print(searcher.num_tested, 'states')

    if soln == None:
        print('Failed to find a solution.')
    else:
        print('Found a solution requiring', soln.num_moves, 'moves.')
        show_steps = input('Show the moves (y/n)? ')
        if show_steps == 'y':
            soln.print_moves_to()

def process_file(filename, algorithm, extra=-1):
    """processes the input text file filename, the input string algorithm that
       specifies which state-space search algorithm should be used to solve the
       puzzles, and the input integer extra that can be used to specify an
       optional parameter for the algorithm being used - either a depth limit or
       a choice of heuristic"""
    file = open(filename, 'r')

    number_puzzles = 0
    states_tested = 0
    num_moves = 0
    for line in file:
        line = line[:-1]      # Chop off newline at end

        init_board = Board(line)                        # Create Board object for inital board
        init_state = State(init_board, None, 'init')    # Create State object for initial state
 
        searcher = create_searcher(init_state, algorithm, extra)  # Create necessary type of Searcher object
        print(line + ': ', end = '')
        if searcher == None:
            return

        soln = None
        try:
            soln = searcher.find_solution()
        except KeyboardInterrupt:
            print('search terminated, ', end='')   # Terminate search by Ctrl-C

        if soln == None:
            print('no solution')
        else:
            print(soln.num_moves, 'moves,', searcher.num_tested, 'states tested')
            number_puzzles += 1
            states_tested += searcher.num_tested
            num_moves += soln.num_moves

    print()
    if number_puzzles == 0:
        print('solved', number_puzzles, 'puzzles')
    else:
        average_states_tested = states_tested / number_puzzles  # Compute average number of states tested
        average_number_moves = num_moves / number_puzzles       # Compute average number of moves for each puzzle
        print('solved', number_puzzles, 'puzzles')
        print('averages:', average_number_moves, 'moves,', average_states_tested, 'states tested')
